// import { catchAsync } from "../utils/catchAsync.js";

// export const getbannerData = catchAsync(async (req, res) => {
//     const
// });
